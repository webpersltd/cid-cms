<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>NBR CID - 404 Page Not Found</title>
<link type="text/css" rel="stylesheet" href="http://localhost/CID/css/error_404.css"/>
</head>
<body>
	<h1>404 Error Page</h1>
	<p class="zoom-area"><b>SORRY</b> Your requested page is not found. </p>
	<section class="error-container">
	  <span>4</span>
	  <span><span class="screen-reader-text">0</span></span>
	  <span>4</span>
	</section>
</body>
</html>