<?php
/**
 * 
 * Enter description here ...
 * @return CI_Controller
 */
function get_instance()
{
	
}